from datetime import datetime, timedelta
import cv2
import numpy as np
import face_recognition
import mysql.connector

# Global variable to store the last attendance time for each student
last_attendance_time = {}

def create_database():
    try:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )

        mycursor = mydb.cursor()
        mycursor.execute("CREATE DATABASE IF NOT EXISTS fyp3")

        print("Database created")

        mycursor.close()
        mydb.close()

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="fyp3"
        )

        mycursor = mydb.cursor()

        # Ensure that both students and attendance tables have student_id column
        mycursor.execute("CREATE TABLE IF NOT EXISTS students (student_id INT AUTO_INCREMENT PRIMARY KEY, student_name VARCHAR(100) UNIQUE NOT NULL, roll_number VARCHAR(50), department VARCHAR(100), course VARCHAR(100), image BLOB)")
        mycursor.execute("CREATE TABLE IF NOT EXISTS attendance (attendance_id INT AUTO_INCREMENT PRIMARY KEY, student_id INT, date DATETIME, status ENUM('Present', 'Absent') DEFAULT 'Present', FOREIGN KEY (student_id) REFERENCES students(student_id))")

        print("Tables created successfully.")

        mycursor.close()
        mydb.close()

    except mysql.connector.Error as error:
        print("Error connecting to MySQL database:", error)

def add_student(name, roll_number, department, course, image_path):
    try:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="fyp3"
        )

        mycursor = mydb.cursor()

        # Check if the student already exists in the database
        mycursor.execute("SELECT student_id FROM students WHERE student_name = %s", (name,))
        existing_student = mycursor.fetchone()

        if existing_student:
            # Update the student record if it already exists
            print(f"Student {name} already exists in the database. Updating record...")
            with open(image_path, 'rb') as file:
                image_data = file.read()
            print("Image data size:", len(image_data))  # Debug line
            if image_data is None:
                print("Error: Image data is None.")
            # Update the student's information and image in the database
            sql = "UPDATE students SET roll_number = %s, department = %s, course = %s, image = %s WHERE student_name = %s"
            val = (roll_number, department, course, image_data, name)
            mycursor.execute(sql, val)
            mydb.commit()
            print(f"Student {name}'s record updated in the database.")

        else:
            # Insert the student into the database if it doesn't exist
            with open(image_path, 'rb') as file:
                image_data = file.read()
            print("Image data size:", len(image_data))  # Debug line
            if image_data is None:
                print("Error: Image data is None.")
            # Insert the student into the database
            sql = "INSERT INTO students (student_name, roll_number, department, course, image) VALUES (%s, %s, %s, %s, %s)"
            val = (name, roll_number, department, course, image_data)
            mycursor.execute(sql, val)
            mydb.commit()
            print(f"Student {name} added to the database.")

    except mysql.connector.Error as error:
        print("Error adding/updating student to the database:", error)

    finally:
        mycursor.close()
        mydb.close()

def find_encoding(images):
    encodelist = []
    for img_data in images:
        try:
            img = cv2.imdecode(np.frombuffer(img_data, np.uint8), -1)
            if img is not None:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                encode = face_recognition.face_encodings(img)[0]
                encodelist.append(encode)
            else:
                print("Error: Decoded image is None.")
        except Exception as e:
            print("Error processing image data:", e)
    return encodelist

def mark_attendance(name):
    try:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="fyp3"
        )

        mycursor = mydb.cursor()

        # Fetch the student ID by case-insensitive comparison
        mycursor.execute("SELECT student_id FROM students WHERE UPPER(student_name) = %s", (name.upper(),))
        student_row = mycursor.fetchone()

        if student_row:
            student_id = student_row[0]
            now = datetime.now()

            # Check if the student's attendance was already marked within the last minute
            last_attendance = last_attendance_time.get(student_id)
            if last_attendance is None or (now - last_attendance) > timedelta(minutes=1):
                # Insert attendance record
                sql = "INSERT INTO attendance (student_id, date) VALUES (%s, %s)"
                val = (student_id, now.strftime('%Y-%m-%d %H:%M:%S'))
                mycursor.execute(sql, val)
                mydb.commit()  # Commit changes to the database
                print("Attendance marked successfully for student:", name)

                # Update last attendance time for the student
                last_attendance_time[student_id] = now
            else:
                # Calculate the time remaining until the next attendance can be marked
                time_remaining = (last_attendance + timedelta(minutes=1)) - now
                print(f"Attendance already marked for student within the last minute. Try again later. Time remaining: {time_remaining}")

        else:
            print("Student not found:", name)

    except mysql.connector.Error as error:
        print("Error marking attendance:", error)

    finally:
        mycursor.close()
        mydb.close()

def main():
    create_database()

    # Add students to the database
    add_student("Ahmad", "20-NTU-CS-1163", "Computer Science", "Data Science", r"D:\FYP RND\trainData\Ahmed.jpeg")
    add_student("Fatima", "20-NTU-CS-1054", "Computer Science", "Data Science", r"D:\FYP RND\trainData\Fatima.jpeg")

    # Load images and encode them for face recognition
    try:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="fyp3"
        )

        mycursor = mydb.cursor()

        mycursor.execute("SELECT image FROM students")
        records = mycursor.fetchall()

        images = [record[0] for record in records]

        encode_list_known = find_encoding(images)
        print("Encoding complete")

        cap = cv2.VideoCapture(0)

        while True:
            success, img = cap.read()
            img_s = cv2.resize(img, (0, 0), None, 0.25, 0.25)
            img_s = cv2.cvtColor(img_s, cv2.COLOR_BGR2RGB)

            faces_cur_frame = face_recognition.face_locations(img_s, model="hog")
            encode_cur_frame = face_recognition.face_encodings(img_s, faces_cur_frame)

            for encode_face, face_loc in zip(encode_cur_frame, faces_cur_frame):
                matches = face_recognition.compare_faces(encode_list_known, encode_face, tolerance=0.5)
                face_dis = face_recognition.face_distance(encode_list_known, encode_face)
                print(face_dis)
                
                if len(face_dis) > 0:  # Check if face_dis is not empty
                    match_index = np.argmin(face_dis)
                    
                    if matches[match_index]:
                        name = [match_index].upper()
                        print(name)
                        y1, x2, y2, x1 = face_loc
                        y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 255, 0), cv2.FILLED)
                        cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                        mark_attendance(name)

            cv2.imshow('webcam', img)
            k = cv2.waitKey(1)
            if k == ord('q'):
                break

    except mysql.connector.Error as error:
        print("Error accessing database:", error)

    finally:
        mycursor.close()
        mydb.close()

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
